-- INSERTS USUARIOS
BEGIN
    INSERT INTO USUARIOS (nombre, contrasena, email, direccion) VALUES ('Andres', 'andres1234', 'andres@shoes.com', 'Calle San Benito');
    INSERT INTO USUARIOS (nombre, contrasena, email, direccion) VALUES ('Manuel', 'manuel1234', 'manuel@shoes.com', 'Calle Pedro Primero');
    INSERT INTO USUARIOS (nombre, contrasena, email, direccion) VALUES ('Ada', 'ada1234', 'ada@shoes.com', 'Calle Los Rosales');
EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Ha habido un error en la transaccion:'||SQLERRM);
    DBMS_OUTPUT.PUT_LINE('Van a deshacerse las inserciones de datos');
    ROLLBACK;
END;


-- INSERTS MARCAS
BEGIN
    INSERT INTO MARCAS (nombre, descripcion, logo, direccion) VALUES ('Nike', 'Marca de zapatillas deportivas', 'nike.jpg', 'Calle San Nike');
    INSERT INTO MARCAS (nombre, descripcion, logo, direccion) VALUES ('Adidas', 'Marca de zapatillas deportivas', 'adidas.jpg', 'Calle San Adidas');
    INSERT INTO MARCAS (nombre, descripcion, logo, direccion) VALUES ('Puma', 'Marca de zapatillas deportiva', 'puma.png', 'Calle San Puma');
    INSERT INTO MARCAS (nombre, descripcion, logo, direccion) VALUES ('Martinelli', 'Marca de zapatos de piel', 'martinelli.png', 'Calle San Martinelli');
    INSERT INTO MARCAS (nombre, descripcion, logo, direccion) VALUES ('Converse', 'Marca de zapatos casuales', 'converse.jpg', 'Calle San Converse');
EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Ha habido un error en la transaccion:'||SQLERRM);
    DBMS_OUTPUT.PUT_LINE('Van a deshacerse las inserciones de datos');
    ROLLBACK;
END;


-- INSERTS PROVEEDORES
BEGIN
    INSERT INTO PROVEEDORES (nombre, direccion, email, cif, pais) VALUES ('Nike S.L.', 'Calle 123', 'nike@proveedor.com', 'A123456', 'EEUU');
    INSERT INTO PROVEEDORES (nombre, direccion, email, cif, pais) VALUES ('Adidas S.L.', 'Calle 456', 'adidas@proveedor.com', 'B123456', 'Canada');
    INSERT INTO PROVEEDORES (nombre, direccion, email, cif, pais) VALUES ('Puma S.L.', 'Calle 789', 'puma@proveedor.com', 'C123456', 'Inglaterra');
    INSERT INTO PROVEEDORES (nombre, direccion, email, cif, pais) VALUES ('Martinelli S.L.', 'Calle 067', 'martinelli@proveedor.com', 'D123456', 'Italia');
    INSERT INTO PROVEEDORES (nombre, direccion, email, cif, pais) VALUES ('Converse S.L.', 'Calle 583', 'converse@proveedor.com', 'E123456', 'Francia');

EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Ha habido un error en la transaccion:'||SQLERRM);
    DBMS_OUTPUT.PUT_LINE('Van a deshacerse las inserciones de datos');
    ROLLBACK;
END;

-- INSERTS ZAPATOS
BEGIN
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Airforce', 36, 'Blanco', 'Mujer', 'Zapatilla Airforce de mujer', 60, 1, 1);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Airmax', 38, 'Dorado', 'Mujer', 'Zapatilla Airmax de mujer', 75, 1, 1);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Airforce', 42, 'Blanco', 'Hombre', 'Zapatilla Airforce de hombre', 60, 1, 1);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Airmax', 44, 'Dorado', 'Hombre', 'Zapatilla Airmax de hombre', 75, 1, 1);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Superstar', 37, 'Negro', 'Mujer', 'Zapatilla Superstar mujer', 45, 2, 2);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Superstyle', 39, 'Amarillo', 'Mujer', 'Zapatilla Superstyle mujer', 56, 2, 2);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Superstar', 41, 'Negro', 'Hombre', 'Zapatilla Superstar hombre', 45, 2, 2);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Superstyle', 43, 'Amarillo', 'Hombre', 'Zapatilla Superstyle hombre', 56, 2, 2);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Smash', 38, 'Plateado', 'Mujer', 'Zapatilla Smash de mujer', 60, 3, 3);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Carina', 40, 'Verde', 'Mujer', 'Zapatilla Carina de mujer', 75, 3, 3);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Smash', 42, 'Plateado', 'Hombre', 'Zapatilla Smash de hombre', 60, 3, 3);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Carina', 44, 'Verde', 'Hombre', 'Zapatilla Carina de hombre', 75, 3, 3);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Blucher', 37, 'Negro', 'Mujer', 'Zapato Blucher mujer', 85, 4, 4);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Empire', 39, 'Marron', 'Mujer', 'Zapato Empire mujer', 110, 4, 4);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Blucher', 41, 'Negro', 'Hombre', 'Zapato Blucher hombre', 85, 4, 4);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Empire', 43, 'Marron', 'Hombre', 'Zapato Empire hombre', 110, 4, 4);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Run Star', 35, 'Lila', 'Mujer', 'Zapatilla Run Star mujer', 60, 5, 5);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Chuck Taylor', 39, 'Azul', 'Mujer', 'Zapatilla Chuck Taylor mujer', 70, 5, 5);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Run Star', 41, 'Lila', 'Hombre', 'Zapatilla Run Star hombre', 60, 5, 5);
    INSERT INTO ZAPATOS (modelo, numero, color, sexo, descripcion, precio, id_marca, id_proveedor) VALUES ('Chuck Taylor', 46, 'Azul', 'Hombre', 'Zapatilla Chuck Taylor hombre', 70, 5, 5);
    
EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Ha habido un error en la transaccion:'||SQLERRM);
    DBMS_OUTPUT.PUT_LINE('Van a deshacerse las inserciones de datos');
    ROLLBACK;
END;