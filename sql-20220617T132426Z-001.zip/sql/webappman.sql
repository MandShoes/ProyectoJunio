-- CREATE tablas

CREATE TABLE USUARIOS(
    id_usuario INT,
    nombre VARCHAR2(50),
    contrasena VARCHAR2(25),
    email VARCHAR2(25),
    direccion VARCHAR2(75),
    CONSTRAINT PK_id_usuario PRIMARY KEY(id_usuario)
);

CREATE TABLE MARCAS(
    id_marca INT,
    nombre VARCHAR2(50),
    descripcion VARCHAR(200),
    logo VARCHAR2(150),
    direccion VARCHAR2(75),
    CONSTRAINT PK_id_marca PRIMARY KEY(id_marca)
);

CREATE TABLE PROVEEDORES(
    id_proveedor INT,
    nombre VARCHAR2(50),
    direccion VARCHAR2(75),
    email VARCHAR2 (25),
    cif VARCHAR2 (50),
    pais VARCHAR2 (30),
    CONSTRAINT PK_id_proveedor PRIMARY KEY(id_proveedor)
);

CREATE TABLE ZAPATOS(
    id_zapato INT,
    modelo VARCHAR2(30),
    numero NUMBER,
    color VARCHAR2(20),
    sexo VARCHAR2(20),
    descripcion VARCHAR2(200),
    precio INT,
    id_marca INT,
    id_proveedor INT,    
    CONSTRAINT PK_id_zapato PRIMARY KEY(id_zapato)
);

ALTER TABLE ZAPATOS ADD CONSTRAINT FK_id_marca_zapato FOREIGN KEY(id_marca) REFERENCES MARCAS(id_marca);
ALTER TABLE ZAPATOS ADD CONSTRAINT FK_id_marca_proveedor FOREIGN KEY(id_proveedor) REFERENCES PROVEEDORES(id_proveedor);

CREATE TABLE COMPRAS(
    fecha_compra DATE,
    pagado INT,
    id_zapato INT,
    id_usuario INT
);

ALTER TABLE COMPRAS ADD CONSTRAINT FK_id_zapato_compra FOREIGN KEY(id_zapato) REFERENCES ZAPATOS(id_zapato);
ALTER TABLE COMPRAS ADD CONSTRAINT FK_id_usuario_compra FOREIGN KEY(id_usuario) REFERENCES USUARIOS(id_usuario);

CREATE TABLE VALORACIONES(
    fecha_valoracion DATE,
    cantidad_estrellas INT,
    descripcion VARCHAR(150),
    id_zapato INT,
    id_usuario INT
);

ALTER TABLE VALORACIONES ADD CONSTRAINT FK_id_zapato_valoracion FOREIGN KEY(id_zapato) REFERENCES ZAPATOS(id_zapato);
ALTER TABLE VALORACIONES ADD CONSTRAINT FK_id_usuario_valoracion FOREIGN KEY(id_usuario) REFERENCES USUARIOS(id_usuario);

--SEQUSUARIOS
CREATE SEQUENCE SEQ_USUARIOS
START WITH 1
INCREMENT BY 1
minvalue 1;

CREATE OR REPLACE TRIGGER usuario_on_insert
  BEFORE INSERT ON USUARIOS 
  REFERENCING NEW AS New OLD AS Old
  FOR EACH ROW
DECLARE
   tmpVar   NUMBER; 
BEGIN
  tmpVar := 0;
  SELECT SEQ_USUARIOS.nextval INTO tmpVar FROM DUAL;
  :new.id_usuario:=tmpVar;
END;

--SEQMARCAS
CREATE SEQUENCE SEQ_MARCAS
START WITH 1
INCREMENT BY 1
minvalue 1;

CREATE OR REPLACE TRIGGER marca_on_insert
  BEFORE INSERT ON MARCAS 
  REFERENCING NEW AS New OLD AS Old
  FOR EACH ROW
DECLARE
   tmpVar   NUMBER; 
BEGIN
  tmpVar := 0;
  SELECT SEQ_MARCAS.nextval INTO tmpVar FROM DUAL;
  :new.id_marca:=tmpVar;
END;

--SEQPROVEEDORES
CREATE SEQUENCE SEQ_PROVEEDORES
START WITH 1
INCREMENT BY 1
minvalue 1;

CREATE OR REPLACE TRIGGER proveedor_on_insert
  BEFORE INSERT ON PROVEEDORES
  REFERENCING NEW AS New OLD AS Old
  FOR EACH ROW
DECLARE
   tmpVar   NUMBER; 
BEGIN
  tmpVar := 0;
  SELECT SEQ_PROVEEDORES.nextval INTO tmpVar FROM DUAL;
  :new.id_proveedor:=tmpVar;
END;

--SEQZAPATOS
CREATE SEQUENCE SEQ_ZAPATOS
START WITH 1
INCREMENT BY 1
minvalue 1;

CREATE OR REPLACE TRIGGER zapato_on_insert
  BEFORE INSERT ON ZAPATOS
  REFERENCING NEW AS New OLD AS Old
  FOR EACH ROW
DECLARE
   tmpVar   NUMBER; 
BEGIN
  tmpVar := 0;
  SELECT SEQ_ZAPATOS.nextval INTO tmpVar FROM DUAL;
  :new.id_zapato:=tmpVar;
END;